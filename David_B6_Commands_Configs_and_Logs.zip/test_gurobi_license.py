from __future__ import annotations

import gurobipy as gp
from gurobipy import GRB


def solve_tiny() -> None:
    model = gp.Model("tiny_license_test")
    model.Params.OutputFlag = 0
    x = model.addVar(lb=0, ub=10, name="x")
    y = model.addVar(lb=0, ub=10, name="y")
    model.addConstr(x + y <= 10)
    model.setObjective(2 * x + y, GRB.MAXIMIZE)
    model.optimize()
    print(f"tiny_test_status={model.Status}")
    print(f"tiny_test_objective={model.ObjVal:.6f}")


def solve_large_size_test() -> None:
    model = gp.Model("large_license_size_test")
    model.Params.OutputFlag = 0
    n = 3000
    x = model.addVars(n, lb=0, ub=1, vtype=GRB.BINARY, name="x")
    model.addConstr(gp.quicksum(x[i] for i in range(n)) <= n // 2)
    model.setObjective(gp.quicksum(x[i] for i in range(n)), GRB.MAXIMIZE)
    model.optimize()
    print(f"large_test_status={model.Status}")
    print(f"large_test_objective={model.ObjVal:.6f}")


if __name__ == "__main__":
    print("Running Gurobi tiny test...")
    solve_tiny()
    print("Running Gurobi large size-limit test...")
    solve_large_size_test()
    print("If both tests solved, the license is not the small size-limited one.")
